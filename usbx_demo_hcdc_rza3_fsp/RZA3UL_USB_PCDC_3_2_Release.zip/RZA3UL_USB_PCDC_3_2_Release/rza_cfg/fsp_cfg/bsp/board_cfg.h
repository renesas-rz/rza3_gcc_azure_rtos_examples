/* generated configuration header file - do not edit */
#ifndef BOARD_CFG_H_
#define BOARD_CFG_H_
#include "../../../rza/board/rza3ul_smarc_qspi/board.h"
#endif /* BOARD_CFG_H_ */
